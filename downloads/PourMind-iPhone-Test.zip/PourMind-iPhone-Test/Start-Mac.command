#!/bin/sh
cd "$(dirname "$0")"
python3 start_testing.py
